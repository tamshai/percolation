#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <assert.h>
#include "mtwister.h"

/* Site percolation for square LxL lattice with periodic boundary conditions */

#define L 32 /* Linear dimension */
#define N (L*L)
#define EMPTY (-N-1)

#define STACKSIZE 100



/* 
For non-root occupied sites, contains the label for the site's parent in the tree
Root sites are marked with a negative value equal to minus the size of the cluster
For unoccupied states the value is EMPTY
*/
int ptr[N];          /* Array of pointers */

/*
Contains a list of the nearest neighbors, change this to work with a different topology
*/
int nn[N][4];        /* Nearest neighbors */

/*
Contains the random occupation order  
*/
int order[N];        /* Occupation order */
//int fixed[N] = {10, 1, 13, 9, 0, 24, 4, 12, 17, 15, 23, 7, 3, 21, 14, 8, 18, 22, 16, 19, 5, 11, 2, 20, 6};

/* Difference vector from the site to the cluster root */
int dx[N];
int dy[N];

/*
Sets up the nearest neighbors according to the chosen topology
periodical boundary conditions
*/
void boundaries()
{
    int i;

    for (i=0; i<N; i++) {
        nn[i][0] = (i+1)%N; /* Right */
        nn[i][1] = (i+N-1)%N; /* Left */
        nn[i][2] = (i+L)%N; /* Down */
        nn[i][3] = (i+N-L)%N; /* Up */
        if (i%L==0) nn[i][1] = i+L-1; /* First column */
        if ((i+1)%L==0) nn[i][0] = i-L+1; /* Last column */
    }
}


/*
Generates the random order in which the sites are occupied, 
randomly permuting the integers from 0 to N-1
*/
void permutation(MTRand *r)
{
    int i,j;
    int temp;

    for (i=0; i<N; i++) order[i] = i; /* Initialization */
    for (i=0; i<N; i++) {dx[i] = 0, dy[i] =0;}; /* Initialization of the displacements*/
    for (i=0; i<N; i++) {

        /* Permute the current integer with a randomly chosen integer
         from further in the list */
        //double drand = rand()/(double)RAND_MAX;
        double drand = genRand(r);
        j = i + (N-i)*drand;
        j = j % N;
        assert(0 <= drand && drand <= 1);
        assert(0 <= j && j < N);

        temp = order[i]; /* Swap i and j */
        order[i] = order[j];
        order[j] = temp;
    }

    /* Comment the next line to randomize the order! */
    //for (i=0; i<N; i++) order[i] = fixed[i];

}



int findroot(int i)
{
    int r; /* Root */
    int sp=0; /* Stack pointer */
    int stack[STACKSIZE];
    int dx_s[STACKSIZE], dy_s[STACKSIZE]; /* Stack of displacements */
    int dx_cum = 0, dy_cum = 0; /* Cumulative displacement */ 

    r = i;

    while (ptr[r]>=0) {
        
        dx_s[sp] = dx[r];
        dy_s[sp] = dy[r];
        stack[sp] = r;
        r = ptr[r];
        sp++;
    }

    while (sp) {
        sp--;
        dx_cum += dx_s[sp];
        dy_cum += dy_s[sp];

        dx[stack[sp]] = dx_cum;
        dy[stack[sp]] = dy_cum;
        ptr[stack[sp]] = r;
    }
    return r;
}


void disp_ptr() {
    for (int i = 0; i < L; i++) {
        printf("\n");
        for (int j = 0; j < L; j++) {
            int p = ptr[i*L+j];
            if (p != EMPTY)
                printf ("   @");
            else
                printf("    ");
        }
    }
    printf("\n");
}

void disp_ord() {
    for (int i=0; i < N; i++) {
        printf("%i, ", order[i] );
    }
    printf("\n");
}


void disp_dist() {
    for (int i = 0; i < L; i++) {
        printf("\n");
        for (int j = 0; j < L; j++) {
            printf ("%4i", dx[i*L+j]);
        }
    }
    printf("\n");; 
    
    for (int i = 0; i < L; i++) {
        printf("\n");
        for (int j = 0; j < L; j++) {
            printf ("%4i", dy[i*L+j]);
        }
    }

    printf("\n");

    for (int i = 0; i < L; i++) {
        printf("\n");
        for (int j = 0; j < L; j++) {
            printf ("%4i", ptr[i*L+j]);
        }
    }
    /*
    printf("\n\n");
    for (int i = 0 ; i < N; i++)
        printf("%i ", order[i]);
    printf("\n");
    */
}


int percolate()
{
    int i,j;
    int s1,s2;
    int r1,r2;
    
    for (i=0; i<N; i++) ptr[i] = EMPTY; /* Initialize lattice*/

    for (i=0; i<N; i++) {

        r1 = s1 = order[i]; /* s1: site which will be occupied */
        ptr[s1] = -1;       /* Cluster of size 1 */ 

        for (j=0; j<4; j++) {   /* Iterate over nearest neighbors */
            s2 = nn[s1][j];     /* s2: neighboring cluster*/ 
            
            if (ptr[s2]!=EMPTY) { /* Merge the clusters */
                r2 = findroot(s2);  /* Find the root of the neighboring cluster */
                
                /* Merge the clusters */
                if (r2!=r1) {               /* r1: root of the newly occupied site */
                    if (ptr[r1]>ptr[r2]) {  /* If the neighboring cluster is larger */
                        ptr[r2] += ptr[r1]; /* Increase the size of the amalgamated cluster*/
                        
                        findroot(s1);
                        
                        ptr[r1] = r2;       /* Set the new root */
                        
                        /* Update the displacements */

                        findroot(s2);
                        dx[r1] = - dx[s1] + dx[s2];
                        dy[r1] = - dy[s1] + dy[s2];
                        
                        /* Unit vector between the two sites */
                        switch (j) {
                            case 0:
                                dx[r1] += + 1;    
                                break;
                            case 1:
                                dx[r1] += - 1;      
                                break;
                            case 2: 
                                dy[r1] += + 1;        
                                break;
                            case 3:  
                                dy[r1] += - 1;        
                                break;
                        }
                        

                        r1 = r2;

                    } else {
                        ptr[r1] += ptr[r2];
                        
                        findroot(s2);
                        
                        ptr[r2] = r1;

                        /* Update the displacements */
                        
                        findroot(s1);
                        dx[r2] = - dx[s2] + dx[s1];
                        dy[r2] = - dy[s2] + dy[s1];

                        /* Find the unit vector between the two sites */
                        
                        switch (j) {
                            case 0:
                                dx[r2] += - 1;   
                                break;
                            case 1:
                                dx[r2] += + 1;  
                                break;
                            case 2:
                                dy[r2] += - 1;        
                                break;
                            case 3:
                                dy[r2] += + 1;        
                                break;
                        }
                        
                    }
                }
                else {
                /* Internal bond, therefore we can test for percolation */

                    int dx1 = 0, dy1 = 0, dx2 = 0, dy2 = 0;

                    findroot(s1);
                    findroot(s2);
                    dx1 = dx[s1];
                    dx2 = dx[s2];
                    dy1 = dy[s1];
                    dy2 = dy[s2];

                    /* Unit vector of the newly added bond */
                    switch (j) {
                        case 0:
                            dx1 += -1;   
                            break;
                        case 1:
                            dx1 += +1;  
                            break;
                        case 2:
                            dy1 += -1;        
                            break;
                        case 3:
                            dy1 += +1;        
                            break;
                    }

                    /* Check for multiply connected cluster */
                    if (abs(dx1-dx2) != 0  || abs(dy1-dy2) != 0 ) {
                    
                        /*
                        if (abs(dx1-dx2) != L && abs(dy1-dy2) != L ) {
                            
                            printf("Percolation?? %i and %i (dx: %i %i, dy: %i %i) \n", 
                                s1, s2, dx1, dx2, dy1, dy2);
                        
                            disp_dist();
                            disp_ptr();
                            disp_ord();
                            printf("Press Enter to Continue");
                            while( getchar() != '\n' );
                        }
                        */

                        /* Printing the percolated configuration to a file */
                        /*FILE *f = fopen("sample.txt", "w");
                        if (f == NULL) {
                            printf("Error opening file!\n");
                            exit(1);
                        }

                        for (int idx = 0; idx < N; idx++) {
                            
                            if (idx % L == 0 && idx) {
                                fprintf(f, "\n");
                            }

                            findroot(idx);
                            if (ptr[idx] == EMPTY) { 
                                fprintf(f, "0 ");
                            }
                            else if (ptr[idx] == r1 || idx == r1) { 
                                fprintf(f, "1 "); 
                            }
                            else { 
                                fprintf(f, "2 "); 
                            }
                        }

                        fclose(f);
                        */
                        /* Return the number of sites occupied*/
                        return (i+1);
                    }

                }
            }
        /*
        disp_dist();
        disp_ptr();
        printf("Press Enter to Continue (s1: %i, s2: %i)\n", s1, s2);
        //while( getchar() != '\n' );
         */
        }
    }
    return N;
}


int main()
{

    srand(time(0)); 
    boundaries();
    int RL[N];
    MTRand r = seedRand(42);

    for (int i = 0; i< N; i++) {
        RL[i] = 0;
    }

    int NUM_SIM = 1e7;
    
    for (int j = 0; j < NUM_SIM; j++) {
        //printf("Run %i\n", j );   
        permutation(&r);

        int nc = percolate();

        for (int i = nc-1; i < N; i++)
                RL[i] += 1;
    }

    for (int i = 0; i < N; i++) {
        printf("%.9g %i\n", (RL[i])/(1.0*NUM_SIM), i+1);
    }
}