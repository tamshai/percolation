import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from timeit import timeit

def conv_from_file(filename):
	with open( filename, 'r') as f:
	    lines = f.readlines()
	    x = np.array([float(line.split()[1]) for line in lines])
	    y = np.array([float(line.split()[0]) for line in lines])


	N = len(x)
	#gauss = (2*3.14*N*p*(1-p))**(-1.0/2)*np.exp(-(n-p*N)**2/(2*N*p*(1-p)))

	pmin = 0.5925
	pmax = 0.5930
	pn = 500
	pp =  np.linspace(pmin,pmax,pn)
	Rp = np.array([ np.sum(binomial(N, p)*y) for p in pp]) # Convolution
	#Rp = np.array( [np.sum( y*(2*3.14*N*p*(1-p))**(-1.0/2)*np.exp(-(n-p*N)**2/(2*N*p*(1-p))) ) for p in pp])

	return pp,Rp



def binomial(N, p):

	# Computing the binomial distribution using the recursive definition 
	nmax = np.floor(N*p).astype(int)
	binom = np.zeros(N+1)
	binom[nmax+1] = 1.0

	for i in range(nmax,-1, -1):
		binom[i] = binom[i+1]*(i+1)*(1-p)/(N-i)/p

	for i in range(nmax, N+1):
		binom[i] = binom[i-1]*(N-i+1)*p/i/(1-p)
	
	binom = binom/np.sum(binom)
	return binom[1:]


def find_nearest(array, value):
    array = np.asarray(array)
    idx = (np.abs(array - value)).argmin()
    return idx


def main():	

	
	fnames = ["perc16.dat", "perc32.dat", "perc64.dat", "perc128.dat", "perc256.dat"]
	LL = np.array([16, 32, 64, 128, 256])
	pcrit = np.zeros(len(fnames))
	
	# Plot
	fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4)) 

	for idx, fname in enumerate(fnames): 
		# Computing the convolution with the binomial distribution
		pp, Rp = conv_from_file(fname)
		
		# Find the root of the equation R_L(p) = R_inf(p_c) =  0.690473725
		Rinf = 0.690473725
		pcrit[idx] = pp[find_nearest(Rp, Rinf)]

		ax1.plot(pp, Rp)

	#print(np.polyfit((LL**(-11/4))[1:], pcrit[1:], 1, full=True))
	x = (LL**(-11/4))[1:]
	y = pcrit[1:]
	p, V = np.polyfit(x, y, 1, cov=True)

	print("Intercept: {} +/- {}".format(p[1], np.sqrt(V[1][1])))

	ax2.plot(LL**(-11/4), pcrit, 'o')
	plt.show()

	"""
	# Drawing the percolating grid
	# Fill in data
	with open('sample.txt') as file:
		data = np.array([[float(digit) for digit in line.split()] for line in file])

	N = data.shape[0]

	# Make a figure + axes
	fig, ax = plt.subplots(1, 1, tight_layout=True)
	# Make color map
	my_cmap = ListedColormap(['w','r', 'k'])
	# Set the 'bad' values (nan) to be white and transparent
	my_cmap.set_bad(color='w', alpha=0)
	# Draw the boxes
	ax.imshow(data, interpolation='none', cmap=my_cmap, extent=[0, N, 0, N], zorder=0)
	# Turn off the axis labels
	ax.axis('off')
	plt.show()
	"""


print(timeit(main, number=1))

